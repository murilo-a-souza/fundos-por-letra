// Plugin logic thread. Runs in an isolated process and talks to the host
// through the injected `spresenter` global. No DOM here — this is where you
// call the app's APIs and hold state.

// Messages coming from the UI (iframe) via postMessage.
spresenter.ui.onmessage = async (raw: unknown) => {
  const msg = raw as { type?: string; query?: string; guid?: string };
  if (!msg || typeof msg !== 'object') return;

  // Search music assets and send the results back to the UI.
  if (msg.type === 'search') {
    const results = await spresenter.assets.search(msg.query ?? '', { type: 'music' });
    spresenter.ui.postMessage({ type: 'search-results', results: results.slice(0, 20) });
    return;
  }

  // Put the first verse of a song live on the first output, layer 0.
  if (msg.type === 'go-live' && msg.guid) {
    const outputs = await spresenter.outputs.list();
    const output = String(outputs[0]?.index ?? 0);
    await spresenter.live.setMusicVerse(output, 0, msg.guid, 0);
    spresenter.ui.postMessage({ type: 'went-live', guid: msg.guid });
  }
};

// React to live changes made anywhere (app UI, remote controller, other plugins).
spresenter.on('live', (payload) => {
  spresenter.ui.postMessage({ type: 'live-changed', output: payload.output });
});

// eslint-disable-next-line no-console
console.log('Plugin loaded:', spresenter.manifest.name);
