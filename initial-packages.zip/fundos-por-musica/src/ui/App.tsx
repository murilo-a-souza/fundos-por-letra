import { useEffect, useState } from 'react';
import { postMessage, onMessage } from '@spresenter/plugin-sdk/ui';
import {
  Root,
  Header,
  Row,
  TextInput,
  Button,
} from '@spresenter/plugin-sdk/ui-kit/react';

interface Asset {
  guid: string;
  title?: string;
  author?: string;
}

// Example UI: search songs and put one live. All privileged work happens in the
// logic thread (code.ts) — the UI only sends/receives messages. Widgets come
// from the shared UI kit (@spresenter/plugin-sdk/ui-kit/react) so the panel
// matches the host app's look; call injectStyles() once (see main.tsx).
export function App() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Asset[]>([]);
  const [liveGuid, setLiveGuid] = useState<string | null>(null);

  useEffect(() => {
    // Receive messages from the logic thread (code.ts).
    return onMessage((raw) => {
      const msg = raw as { type?: string; results?: Asset[]; guid?: string };
      if (msg.type === 'search-results') setResults(msg.results ?? []);
      if (msg.type === 'went-live') setLiveGuid(msg.guid ?? null);
    });
  }, []);

  const search = () => postMessage({ type: 'search', query });
  const goLive = (guid: string) => postMessage({ type: 'go-live', guid });

  return (
    <Root>
      <Header title="fundos-por-musica" subtitle="Search a song and send it live." />

      <Row>
        <TextInput
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && search()}
          placeholder="Search songs…"
        />
        <Button variant="primary" onClick={search}>
          Search
        </Button>
      </Row>

      <ul
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 4,
          margin: 0,
          padding: 0,
          listStyle: 'none',
          overflowY: 'auto',
        }}
      >
        {results.map((asset) => {
          const isLive = liveGuid === asset.guid;
          return (
            <li
              key={asset.guid}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 8,
                padding: '8px 12px',
                borderRadius: 'var(--sp-radius)',
                background: isLive
                  ? 'rgba(46, 204, 113, 0.14)'
                  : 'var(--sp-bg-elevated)',
              }}
            >
              <div style={{ minWidth: 0 }}>
                <p
                  style={{
                    margin: 0,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {asset.title ?? asset.guid}
                </p>
                {asset.author && (
                  <p
                    style={{
                      margin: 0,
                      fontSize: 12,
                      color: 'var(--sp-text-muted)',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {asset.author}
                  </p>
                )}
              </div>
              <Button
                size="sm"
                variant={isLive ? 'success' : 'secondary'}
                onClick={() => goLive(asset.guid)}
              >
                Go live
              </Button>
            </li>
          );
        })}
        {results.length === 0 && (
          <li
            style={{
              padding: '2px 4px',
              fontSize: 13,
              fontStyle: 'italic',
              color: 'var(--sp-text-faint)',
            }}
          >
            No results yet.
          </li>
        )}
      </ul>
    </Root>
  );
}
